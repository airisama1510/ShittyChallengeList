# Welcome to the Official Geometry Dash Shitty Challenge List repo!
---
There isnt much going on here at the moment but the list team will actively be adding new records and levels, so keep an eye out on the [website](https://scl.krisgra.repl.co/).
---
# FAQ
---
### Website FAQ
Can I use the Shitty List template?
- I mean, sure. head over to [releases](https://github.com/ElectroFlameOfficial/gdshittylist/releases) and choose the latest release. just make sure you give credit somewhere and make sure you state that you're not affiliated with the shitty list

The website isnt loading! What can I do?
- since no webhost is perfect, downtime is expected. you can either wait until the website is back online or you can do some behind the scene stuff and run it locally.
---
### List FAQ
How long will my record take to get accepted?
- Currently our staff is VERY INACTIVE so it'll take like a week lol

What's an easy way to prove I don't hack?
- Show 2-5 seconds at the end of the previous attempt and the death of that attempt. This is the easiest way for us to verify you arent hacking/nocliping. However having click, fps counter or hand cam will help out a lot too

It's been like more than a week and my record still hasn't been added, what do i do?
- You can ask us in [#list-discussion](https://discord.gg/5YuuWrzMyU), it was probably an accidentally deleted record(yes it happens), accidentally deleting the form, your name was mispelled or you were rejected for cheating

When will ___ be added to the list? 
- With the way our current system works, the staff and reliables check if the levels meet our standards, if the level fits the standards it will get added to the list in like 0-2 days

Can I submit Multiple levels on 1 video?
- Yes
---
More Coming Soon!
---
# List Staff Team
---
## Owners:
- Krisgra
---
## List Admins:
- SEDTHEPRODIGY
- KylashTheKiller
- Grilled
---
## List Moderators:
- Brooke
- BlizzardLaZario
---
## Server Administrators:
- Ludwig Drums
---
## Server Moderators:
- Jasker
- Pudgy
---
## Repo Maintainers:
- KrisGra
- Plast
