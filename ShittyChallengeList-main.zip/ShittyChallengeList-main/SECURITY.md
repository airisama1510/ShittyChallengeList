# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 3.x     | :white_check_mark: |

## Reporting a Vulnerability

You can Report vulnerabilities through the
[Discord Server](https://discord.gg/gN826WxqcG) or by DM'ing KrisGra (KrisGra#0209) or Aneko (姉子咲く#8566).
Responses to vulnerability reports usually take around 3 hours to more than a day, depending on how difficult fixing a vulnerability is.